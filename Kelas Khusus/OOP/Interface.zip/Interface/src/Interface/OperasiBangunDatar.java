package Interface;

public interface OperasiBangunDatar {
    double getKeliling();
    double getLuas();
}
