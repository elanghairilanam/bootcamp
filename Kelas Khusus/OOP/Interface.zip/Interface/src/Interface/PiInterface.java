package Interface;

public interface PiInterface {
    static final double PI_Value = 3.14;
}
